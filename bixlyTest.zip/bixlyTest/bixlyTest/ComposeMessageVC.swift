//
//  ComposeMessageVC.swift
//  bixlyTest
//
//  Created by Dhruvin Gajjar on 7/21/17.
//  Copyright © 2017 Dhruvin Gajjar. All rights reserved.
//

import UIKit

class ComposeMessageVC: UIViewController {
    
    var message: User? = nil
    
    @IBOutlet weak var messageTextField: UITextView!
    
    
    @IBAction func sendMessage(_ sender: UIButton) {
        
        let message: String = messageTextField.text!
        
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
