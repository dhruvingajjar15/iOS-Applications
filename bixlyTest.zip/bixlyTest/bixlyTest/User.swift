//
//  User.swift
//  bixlyTest
//
//  Created by Dhruvin Gajjar on 7/21/17.
//  Copyright © 2017 Dhruvin Gajjar. All rights reserved.
//

import Foundation
import UIKit


class User: NSObject{
    
    var username: String
    var password: String
    
    init(username: String, password: String) {
        self.username = username
        self.password = password
        
        super.init()
    }
    
}
