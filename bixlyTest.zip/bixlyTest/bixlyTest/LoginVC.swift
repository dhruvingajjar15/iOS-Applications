//
//  LoginVC.swift
//  bixlyTest
//
//  Created by Dhruvin Gajjar on 7/21/17.
//  Copyright © 2017 Dhruvin Gajjar. All rights reserved.
//

import UIKit
import Alamofire

class LoginVC: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    @IBAction func loginBtn(_ sender: UIButton) {
        let username = emailTextField.text!
        let password = passwordTextField.text!
        
        userLogin(username, password)
        if username == "test" && password == "test123!" {
               performSegue(withIdentifier: "nextView", sender: self)
        }
 
        else if username == "" || password == "" {
            let alert = UIAlertController(title: "Alert", message: "Please enter your username or password", preferredStyle: UIAlertControllerStyle.alert)
            let dismiss = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {(action: UIAlertAction!) in print("Ok button pressed")}
            alert.addAction(dismiss)
            self.present(alert, animated: true, completion: nil)
        }
        else {
            let alert = UIAlertController(title: "Alert", message: "Please enter valid username or password", preferredStyle: UIAlertControllerStyle.alert)
            let dismiss = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default) {(action: UIAlertAction!) in print("Ok button pressed")}
            alert.addAction(dismiss)
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    func hideKeyboard() {
        view.endEditing(true)
    }
    
    func userLogin(_ user: String, _ password:String) {
        let url = URL(string: "https://iostest.bixly.com/api-token-auth/\(user)\(password)")
        let session = URLSession.shared
        
        let request = NSMutableURLRequest(url: url!)
        request.httpMethod = "POST"
        
        let paramToSend = "username" + user + "password" + password
        
        request.httpBody = paramToSend.data(using: String.Encoding.utf8)
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: {
            (data, response, error) in
            
            guard let _: Data = data else {
                return
            }
            
            let json: Any?
            
            do {
                json = try JSONSerialization.jsonObject(with: data!, options: [])
                
            }catch {
                return
            }
            
            guard let server_response = json as? NSDictionary else { return }
            
            if let data_block = server_response["data"] as? NSDictionary {
                if let session_data = data_block["session"] as? String {
                    let preference = UserDefaults.standard
                    preference.set(session_data, forKey: "session")
                    
                    DispatchQueue.main.async(
                        execute: self.LoginDone
                    )
                    
                }
            }
        
        })
        
        task.resume()
        
    }
    
    func LoginDone() {
        emailTextField.isEnabled = false
        passwordTextField.isEnabled = false
        
        loginButton.setTitle("Logout", for: .normal)
    }
    
    func LoginToDo() {
        emailTextField.isEnabled = true
        passwordTextField.isEnabled = true
        
        loginButton.setTitle("Login", for: .normal)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.emailTextField.delegate = self
        self.passwordTextField.delegate = self
        
        let preferences = UserDefaults.standard
        if (preferences.object(forKey: "session") != nil) {
            LoginDone()
        } else {
            LoginToDo()
        }
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideKeyboard))
        view.addGestureRecognizer(tapGesture)
    }


}

