//
//  InboxVC.swift
//  bixlyTest
//
//  Created by Dhruvin Gajjar on 7/21/17.
//  Copyright © 2017 Dhruvin Gajjar. All rights reserved.
//

import UIKit

class InboxVC: UITableViewController {
    
    var items = ["Inbox", "Sent", "Delete","Compose"]
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        let title = items.count
    
        return items.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        var currentItem = items[indexPath.row]
        cell.textLabel?.text = currentItem

        // Configure the cell...

        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "composeView" {
            guard let navController = segue.destination as? UINavigationController else{ return }
            guard let viewController = navController.topViewController as? ComposeMessageVC else { return }
            guard let indexPath = tableView.indexPathForSelectedRow else { return }
            let message = items[indexPath.row]
            
        }
    }
 
}
